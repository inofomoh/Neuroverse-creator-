#include <iostream>
#include "Core/EngineCore.h"
#include "Player/PlayerController.h"
#include "Camera/CameraSystem.h"
#include "Scene/SceneManager.h"
#include "AI/EnemyAI.h"

int main() {
    Engine::Init();
    Camera::Setup();
    Scene::Load("Silent City");
    Player::Control();
    AI::SpawnEnemies();
    Engine::Shutdown();
    return 0;
}
