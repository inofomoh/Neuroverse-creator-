#include <iostream>
#include "PlayerController.h"
void Player::Control() {
    std::cout << "🎮 Player ready! Use WASD to move, SPACE to jump (Simulated).
";
}
