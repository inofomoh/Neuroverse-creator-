#pragma once
namespace Player {
    void Control();
}
