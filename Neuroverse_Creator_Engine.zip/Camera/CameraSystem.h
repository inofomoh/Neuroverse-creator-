#pragma once
namespace Camera {
    void Setup();
}
