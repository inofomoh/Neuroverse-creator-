#include <iostream>
#include "CameraSystem.h"
void Camera::Setup() {
    std::cout << "🎥 Camera initialized. FPS view enabled.
";
}
