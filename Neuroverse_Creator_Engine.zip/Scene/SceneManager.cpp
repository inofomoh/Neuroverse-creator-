#include <iostream>
#include "SceneManager.h"
void Scene::Load(const std::string& sceneName) {
    std::cout << "🌍 Scene loaded: " << sceneName << std::endl;
}
