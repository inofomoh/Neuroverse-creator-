#pragma once
#include <string>
namespace Scene {
    void Load(const std::string& sceneName);
}
