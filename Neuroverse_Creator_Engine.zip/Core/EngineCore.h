#pragma once
namespace Engine {
    void Init();
    void Shutdown();
}
