#include <iostream>
#include "EngineCore.h"
void Engine::Init() {
    std::cout << "🧠 Neuroverse Creator Engine Booting...
";
}
void Engine::Shutdown() {
    std::cout << "✅ Neuroverse Engine Shutdown.
";
}
