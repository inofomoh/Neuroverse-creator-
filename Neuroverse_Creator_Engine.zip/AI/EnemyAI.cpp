#include <iostream>
#include "EnemyAI.h"
void AI::SpawnEnemies() {
    std::cout << "👹 Enemies spawned with basic logic...
";
}
