#pragma once
namespace AI {
    void SpawnEnemies();
}
